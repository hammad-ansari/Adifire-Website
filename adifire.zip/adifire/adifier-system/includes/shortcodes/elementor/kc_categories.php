<?php
if( !class_exists('Adifier_Elementor_kc_categories') ){
class Adifier_Elementor_kc_categories extends Adifier_Elementor_Base {

}
}
?>