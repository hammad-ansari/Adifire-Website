<?php
if( !class_exists('Adifier_Elementor_kc_round_icon') ){
class Adifier_Elementor_kc_round_icon extends Adifier_Elementor_Base {

}
}
?>