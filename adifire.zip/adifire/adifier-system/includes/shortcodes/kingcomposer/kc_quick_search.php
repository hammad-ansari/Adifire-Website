<form method="post" class="ajax-form element-qs"  autocomplete="off">

	<div class="adifier-form quick-search-form">
		<input type="text" value="" name="s" placeholder="<?php esc_attr_e( 'Search for... (min 4 chars)', 'adifier' ); ?>">
		<a href="javascript:void(0);" class="quick-search-status"></a>
	</div>

	<div class="ajax-form-result"></div>
</form>