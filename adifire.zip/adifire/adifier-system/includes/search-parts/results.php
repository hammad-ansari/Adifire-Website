<div class="ajax-search">
	<?php
	if( $adverts->have_posts() ){
		?>
		<div class="white-block">
			<div class="white-block-content">
				<div class="flex-wrap search-order">
					<h6>
						<?php esc_html_e( 'Showing ', 'adifier' ); ?>
						<strong><?php echo esc_html( ( $page - 1 ) * $per_page + 1 ) ?></strong>
						-
						<strong><?php echo $page * $per_page > $adverts->found_posts ? esc_html( $adverts->found_posts ) : esc_html( $page * $per_page ) ?></strong> 
						<?php esc_html_e( 'of', 'adifier' ); ?>
						<strong><?php echo esc_html( $adverts->found_posts ) ?></strong>
						<?php $adverts->found_posts == 1 ? esc_html_e( 'ad found', 'adifier' ) : esc_html_e( 'ads found', 'adifier' ); ?>
					</h6>
					<div class="flex-right flex-wrap">
						<div class="styled-select styled-select-no-label">
							<select name="af_orderby" class="orderby">
								<option value="" <?php selected( '', $orderby ) ?>><?php esc_html_e( 'Sort By Date', 'adifier' ) ?></option>
								<option value="expire-ASC" <?php selected( 'expire-ASC', $orderby ) ?>><?php esc_html_e( 'Sort By Expire', 'adifier' ) ?></option>
								<option value="views-DESC" <?php selected( 'views-DESC', $orderby ) ?>><?php esc_html_e( 'Sort By Popularity', 'adifier' ) ?></option>
								<option value="price-ASC" <?php selected( 'price-ASC', $orderby ) ?>><?php esc_html_e( 'Sort By Price - Ascending', 'adifier' ) ?></option>
								<option value="price-DESC" <?php selected( 'price-DESC', $orderby ) ?>><?php esc_html_e( 'Sort By Price - Descending', 'adifier' ) ?></option>
							</select>
						</div>
						<div class="layout-view">
							<a href="javascript:void(0);" class="<?php echo  $layout == 'grid' ? esc_attr( 'active' ) : esc_attr( '' ) ?>" data-style="grid"><i class="aficon-th"></i></a>
							<a href="javascript:void(0);" class="<?php echo  $layout == 'list' ? esc_attr( 'active' ) : esc_attr( '' ) ?>" data-style="list"><i class="aficon-th-list"></i></a>
							<a href="javascript:void(0);" class="<?php echo  $layout == 'card' ? esc_attr( 'active' ) : esc_attr( '' )  ?>" data-style="card"><i class="aficon-th-large"></i></a>
						</div>
					</div>
				</div>
			</div>
		</div>

		<div class="af-items-<?php echo  $layout == 'list' ? esc_attr( 1 ) : ( $layout == 'card' ? esc_attr( 2 ) : esc_attr( $result_listing ) )  ?> <?php echo esc_attr('af-listing-'.$layout) ?>" >
			<?php
			while( $adverts->have_posts() ){
				$adverts->the_post();
				echo '<div class="af-item-wrap">';
					include( get_theme_file_path( 'includes/advert-boxes/'.$layout.'.php' ) );
				echo '</div>';
			}
			?>

			<div class="af-items-1 af-listing-list">
        <?php 
        $url="https://adzarabia.com/wp-json/wp/v2/advert?lang=ar";
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_URL,$url);
        $result=curl_exec($ch);
        $Arposts = json_decode($result, true);

        foreach($Arposts as $post){ 
// 			echo '<pre>';
// 			print_r($post['id']);
// 			echo '</pre>';
            
			
			
			$post_title = $post['title']['rendered'];
            $post_excerpt = $post['excerpt']['rendered']; ?>

            <div class="af-item-wrap">
             <div class="white-block hover-shadow advert-item advert-list ">
                <div class="flex-wrap flex-start-h">
                    <div class="flex-left">
                        <a href="<?= $post['link']; ?>">
                            <?php   foreach($post['_links']['wp:featuredmedia'] as $img){
                            
                            $img_api_url = $img['href'];
                            $url= $img_api_url;
                            $ch = curl_init();
                            curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
                            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
                            curl_setopt($ch, CURLOPT_URL,$url);
                            $result=curl_exec($ch);
                            $img_api_json = json_decode($result, true);
                            
                            $featured_img = $img_api_json['guid']['rendered'];?>
                            
                            <img width="355" height="400" src="<?= $featured_img ?>" class="attachment-adifier-list size-adifier-list wp-post-image" alt="" loading="lazy"> 
                     
                     <?php   } ?>
                                    
                        </a>
                    </div>
                    <div class="flex-right">
                        <div class="white-block-content">
                            <div class="top-advert-meta flex-wrap">
                                <div class="advert-cat text-overflow">
                                    <i class="aficon-dot-circle-o"></i>
                        <?php   foreach($post['_links']['wp:term'] as $term){

                            $term_api_url = $term['href'];
                            $url= $term_api_url;
                            $ch = curl_init();
                            curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
                            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
                            curl_setopt($ch, CURLOPT_URL,$url);
                            $result=curl_exec($ch);
                            $term_api_json = json_decode($result, true);
                            foreach($term_api_json as $category){
                                
                            $category_name = $category['name'];?>
                                <a href="<?= $category['link'] ?>"><?php echo $category_name; ?></a>
                       <?php }
                   } ?>
                                                
                                </div>          
                                <div class="advert-city text-overflow">
                                </div>
                            </div>
                            <h5 class="adv-title">
                                <a href="<?php echo $post['link']; ?>">
                                <?php echo $post_title; ?>   </a>
                            </h5>

                            <p class="excerpt">
                                <?php echo $post_excerpt; ?>               
                            </p>

                            <div class="bottom-advert-meta flex-wrap">
                                <div class="price">
								<?php	global $wpdb;
								  $results = $wpdb->get_results( "SELECT * FROM wp_adifier_advert_data WHERE post_id = ".$post['id']  );
									foreach($results as $res) { ?>
											
										<span class="price-symbol">BD</span><?php echo $res->price; ?>
											
										<?php } ?>
                                    
                                </div>   
                                <div class="flex-right">
                                    <!-- <a href="javascript:void(0);" class="compare-add " data-id="2055" title="Add This To Compare">
                                        <i class="aficon-repeat"></i>
                                    </a> --> 
                                    <?php if( adifier_get_option( 'enable_compare' ) == 'yes' ): ?>
                                        <a href="javascript:void(0);" class="compare-add <?php echo adifier_is_in_compare( get_the_ID() ) ? esc_attr( 'active' ) : esc_attr(''); ?>" data-id="<?php echo esc_attr( get_the_ID() ) ?>" title="<?php esc_attr_e( 'Add This To Compare', 'adifier' ) ?>">
                                            <i class="aficon-repeat"></i>
                                        </a>            
                                    <?php endif; ?>            
                                    <?php adifier_get_favorites_html() ?>
                                    <!-- <a title="Favorite" href="javascript:void(0);" class="process-favorites " data-id="2055">
                                        <i class="aficon-heart-o"></i>
                                        <span>Favorite</span>
                                        <span class="small-icon">Favorite</span>
                                    </a> -->
                                </div>
                            </div>              
                        </div>
                    </div>
                </div>
                <div class="search-map-la-long hidden" data-id="2055" data-longitude="0.00000000" data-latitude="0.00000000" data-icon="https://www.adzarabia.com/wp-content/uploads/2019/07/books.png" data-iconwidth="512" data-iconheight="512">
                </div>
            </div>
        </div>

        <?php } ?> 
    </div>





			
		</div>

		
		<?php
		if( !empty( $pagination ) ){
			?>
			<div class="pagination">
				<?php echo $pagination ?>
			</div>
			<?php
		}
		?>

		<?php
	}
	else{
		?>
		<div class="white-block no-advert-found">
			<div class="white-block-content text-center">
				<i class="aficon-question-circle"></i>
				<h6><?php esc_html_e( 'No ads found matched your criteria', 'adifier' ) ?></h6>
			</div>
		</div>
		<?php
	}

	?>
</div>