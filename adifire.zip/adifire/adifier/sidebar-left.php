<?php
if ( is_active_sidebar( 'left' ) ){
	dynamic_sidebar( 'left' );
}
?>