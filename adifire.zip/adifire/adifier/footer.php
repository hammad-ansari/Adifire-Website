<a href="javascript:;" class="to_top af-button">
	<i class="aficon-angle-up"></i>
</a>

<?php do_action( 'adifier_footer' ); ?>

<?php wp_footer(); ?>
</body>
</html>