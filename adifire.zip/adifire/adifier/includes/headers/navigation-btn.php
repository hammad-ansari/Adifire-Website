<a href="javascript:void(0);" class="small-sidebar-open navigation-trigger" data-target=".navigation-wrap">
	<i class="aficon-align-justify"></i>
	<span class="small-icon"><?php esc_html_e( 'Menu', 'adifier' ) ?></span>
</a>